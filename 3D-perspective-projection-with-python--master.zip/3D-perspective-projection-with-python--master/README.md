# 3D-perspective-projection-with-python-

#### please check out my youtube channel : https://www.youtube.com/channel/UCjPk9YDheKst1FlAf_KSpyA
---
## here are better versions which support faces and triangles: 
#### - https://github.com/Josephbakulikira/Simple-3D-engine-pygame
#### - https://github.com/Josephbakulikira/3D-engine-from-scraph--pygame
